package com.ubs.wmi.workflow.search;

import java.util.Locale;

import com.ubs.wmi.workflow.core.config.WorkflowPlatformProperties;

/**
 * Builds Elasticsearch index names consistently across every workflow application, so a
 * shared cluster stays navigable and an application can never write into a neighbour's index
 * by accident.
 */
public class IndexNameResolver {

    private final SearchProperties searchProperties;
    private final WorkflowPlatformProperties platformProperties;

    public IndexNameResolver(SearchProperties searchProperties,
                             WorkflowPlatformProperties platformProperties) {
        this.searchProperties = searchProperties;
        this.platformProperties = platformProperties;
    }

    /**
     * @param logicalName e.g. "cases", "tasks", "documents"
     */
    public String resolve(String logicalName) {
        String name = logicalName.toLowerCase(Locale.ROOT);
        return switch (searchProperties.getIsolation()) {
            case INDEX_PER_APP -> String.join("-",
                    searchProperties.getIndexPrefix(),
                    searchProperties.getEnvironment(),
                    platformProperties.getAppKey(),
                    name);
            case SHARED_WITH_TENANT_FILTER -> String.join("-",
                    searchProperties.getIndexPrefix(),
                    searchProperties.getEnvironment(),
                    name);
        };
    }

    /** Write alias, so reindexing can swap the underlying index without downtime. */
    public String writeAlias(String logicalName) {
        return resolve(logicalName) + "-write";
    }
}
