package com.ubs.wmi.workflow.search;

import com.ubs.wmi.workflow.core.config.WorkflowPlatformProperties;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@EnableConfigurationProperties({SearchProperties.class, WorkflowPlatformProperties.class})
public class SearchAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(IndexNameResolver.class)
    public IndexNameResolver indexNameResolver(SearchProperties searchProperties,
                                               WorkflowPlatformProperties platformProperties) {
        return new IndexNameResolver(searchProperties, platformProperties);
    }
}
