package com.ubs.wmi.workflow.search;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "wmi.workflow.search")
public class SearchProperties {

    public enum IsolationMode {
        /** One index namespace per application: wmi-<appKey>-<logical>. Hard isolation. */
        INDEX_PER_APP,
        /** Shared indices, every document carries tenantId and queries filter on it. */
        SHARED_WITH_TENANT_FILTER
    }

    /**
     * Default is INDEX_PER_APP. Choose SHARED_WITH_TENANT_FILTER only if you genuinely need
     * cross-application dashboards inside one index; otherwise aggregate in Kibana/Grafana
     * instead and keep the blast radius small.
     */
    private IsolationMode isolation = IsolationMode.INDEX_PER_APP;

    /** Prefix applied to every index name. */
    private String indexPrefix = "wmi";

    /** Environment discriminator so dev/uat/prod never share an index on a shared cluster. */
    private String environment = "local";

    public IsolationMode getIsolation() { return isolation; }
    public void setIsolation(IsolationMode v) { this.isolation = v; }
    public String getIndexPrefix() { return indexPrefix; }
    public void setIndexPrefix(String v) { this.indexPrefix = v; }
    public String getEnvironment() { return environment; }
    public void setEnvironment(String v) { this.environment = v; }
}
