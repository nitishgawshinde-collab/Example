package com.ubs.wmi.workflow.core.service;

import java.util.Map;

import com.ubs.wmi.workflow.core.tenant.TenantResolver;
import org.flowable.task.api.Task;
import org.flowable.task.api.TaskQuery;
import org.flowable.engine.TaskService;

/** Tenant-scoped entry point for human task operations. */
public class PlatformTaskFacade {

    private final TaskService taskService;
    private final TenantResolver tenantResolver;

    public PlatformTaskFacade(TaskService taskService, TenantResolver tenantResolver) {
        this.taskService = taskService;
        this.tenantResolver = tenantResolver;
    }

    public TaskQuery query() {
        return taskService.createTaskQuery()
                .taskTenantId(tenantResolver.currentTenantId());
    }

    /** Completes a task only if it belongs to the current tenant. */
    public void complete(String taskId, Map<String, Object> variables) {
        Task task = query().taskId(taskId).singleResult();
        if (task == null) {
            throw new IllegalArgumentException(
                    "Task " + taskId + " not found for tenant " + tenantResolver.currentTenantId());
        }
        taskService.complete(taskId, variables);
    }

    public TaskService unsafeTaskService() {
        return taskService;
    }
}
