package com.ubs.wmi.workflow.core.config;

import java.util.List;

import org.flowable.cmmn.spring.SpringCmmnEngineConfiguration;
import org.flowable.common.engine.impl.AbstractEngineConfiguration;
import org.flowable.spring.SpringProcessEngineConfiguration;
import org.flowable.spring.boot.EngineConfigurationConfigurer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * Applies platform-wide engine policy without owning the engine beans themselves.
 * <p>
 * Flowable calls every {@link EngineConfigurationConfigurer} bean before building an
 * engine, so an application can still add its own configurer (expressions, custom
 * session factories, history level) without fighting the platform, and can replace
 * these by declaring a bean with the same name.
 */
@AutoConfiguration
@EnableConfigurationProperties(WorkflowPlatformProperties.class)
public class WorkflowEngineAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(WorkflowEngineAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean(name = "platformProcessEngineConfigurer")
    public EngineConfigurationConfigurer<SpringProcessEngineConfiguration>
            platformProcessEngineConfigurer(WorkflowPlatformProperties props) {

        List<String> categories = props.resolvedJobCategories();
        log.info("Flowable BPMN engine policy: tenant={}, jobCategories={}, schemaUpdate={}",
                props.resolvedTenantId(), categories, props.isDatabaseSchemaUpdate());

        return configuration -> {
            configuration.setDatabaseSchemaUpdate(props.isDatabaseSchemaUpdate()
                    ? AbstractEngineConfiguration.DB_SCHEMA_UPDATE_TRUE
                    : AbstractEngineConfiguration.DB_SCHEMA_UPDATE_FALSE);
            configuration.setAsyncExecutorActivate(props.getJobs().isAsyncExecutorEnabled());
            configuration.setEnabledJobCategories(categories);
            configuration.setAsyncFailedJobWaitTime(props.getJobs().getFailedJobWaitTime());
        };
    }

    @AutoConfiguration
    @ConditionalOnClass(SpringCmmnEngineConfiguration.class)
    @EnableConfigurationProperties(WorkflowPlatformProperties.class)
    public static class CmmnPolicyConfiguration {

        @Bean
        @ConditionalOnMissingBean(name = "platformCmmnEngineConfigurer")
        public EngineConfigurationConfigurer<SpringCmmnEngineConfiguration>
                platformCmmnEngineConfigurer(WorkflowPlatformProperties props) {
            return configuration -> {
                configuration.setDatabaseSchemaUpdate(props.isDatabaseSchemaUpdate()
                        ? AbstractEngineConfiguration.DB_SCHEMA_UPDATE_TRUE
                        : AbstractEngineConfiguration.DB_SCHEMA_UPDATE_FALSE);
                configuration.setEnabledJobCategories(props.resolvedJobCategories());
            };
        }
    }
}
