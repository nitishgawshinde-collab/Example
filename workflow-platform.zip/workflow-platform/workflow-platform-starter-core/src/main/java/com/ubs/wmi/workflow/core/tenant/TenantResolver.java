package com.ubs.wmi.workflow.core.tenant;

/**
 * Resolves the Flowable tenant for the current execution.
 * <p>
 * The platform default is a fixed tenant per application. An application that is itself
 * multi-tenant (for example one service per booking centre) overrides this bean and
 * resolves from the security context, an HTTP header or a JWT claim instead.
 */
public interface TenantResolver {

    String currentTenantId();
}
