package com.ubs.wmi.workflow.core.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;

/**
 * Contributes platform defaults at the LOWEST precedence, so anything an application
 * puts in its own application.yaml (or an env var, or a Key Vault secret) still wins.
 * <p>
 * Registered through META-INF/spring.factories.
 */
public class PlatformDefaultsEnvironmentPostProcessor implements EnvironmentPostProcessor {

    public static final String PROPERTY_SOURCE_NAME = "workflow-platform-defaults";

    @Override
    public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
        String appKey = environment.getProperty("wmi.workflow.app-key", "unset");

        Map<String, Object> defaults = new HashMap<>();
        // Liquibase: platform master changelog picks up app changesets via includeAll.
        defaults.put("spring.liquibase.change-log", "classpath:db/changelog/db.changelog-master.yaml");
        defaults.put("spring.liquibase.contexts", appKey);
        defaults.put("spring.liquibase.parameters.appKey", appKey);

        // Flowable's own auto schema handling is driven by the platform configurer instead.
        defaults.put("flowable.database-schema-update", "false");
        // Async history off by default; switch on per app after load testing.
        defaults.put("flowable.async-history.enable", "false");

        defaults.put("management.endpoints.web.exposure.include", "health,info,metrics,prometheus");

        environment.getPropertySources().addLast(new MapPropertySource(PROPERTY_SOURCE_NAME, defaults));
    }
}
