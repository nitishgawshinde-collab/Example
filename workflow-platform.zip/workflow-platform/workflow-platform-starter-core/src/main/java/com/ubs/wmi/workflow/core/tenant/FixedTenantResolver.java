package com.ubs.wmi.workflow.core.tenant;

import java.util.Objects;

/** One tenant for the whole application, taken from wmi.workflow.app-key. */
public class FixedTenantResolver implements TenantResolver {

    private final String tenantId;

    public FixedTenantResolver(String tenantId) {
        this.tenantId = Objects.requireNonNull(tenantId, "tenantId must not be null");
    }

    @Override
    public String currentTenantId() {
        return tenantId;
    }
}
