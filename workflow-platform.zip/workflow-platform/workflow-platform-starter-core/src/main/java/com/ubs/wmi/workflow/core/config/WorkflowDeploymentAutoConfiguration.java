package com.ubs.wmi.workflow.core.config;

import java.io.InputStream;
import java.util.zip.ZipInputStream;

import com.ubs.wmi.workflow.core.tenant.TenantResolver;
import org.flowable.engine.RepositoryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

/**
 * Deploys Flowable Design app exports (classpath:apps/*.zip) under this application's
 * tenant, with duplicate filtering so restarts do not pile up deployment versions.
 * <p>
 * Plain BPMN/CMMN/DMN files under classpath:processes|cases|dmn are still handled by
 * Flowable's own auto-deployment; this runner only covers packaged app archives.
 */
@AutoConfiguration(after = WorkflowEngineAutoConfiguration.class)
@ConditionalOnProperty(prefix = "wmi.workflow.deployment", name = "enabled",
                       havingValue = "true", matchIfMissing = true)
public class WorkflowDeploymentAutoConfiguration {

    private static final Logger log = LoggerFactory.getLogger(WorkflowDeploymentAutoConfiguration.class);
    private static final String APP_ARCHIVES = "classpath*:apps/*.zip";

    @Bean
    @ConditionalOnBean(RepositoryService.class)
    @ConditionalOnMissingBean(name = "platformAppDeployer")
    public ApplicationRunner platformAppDeployer(RepositoryService repositoryService,
                                                 TenantResolver tenantResolver) {
        return args -> {
            String tenantId = tenantResolver.currentTenantId();
            Resource[] archives = new PathMatchingResourcePatternResolver().getResources(APP_ARCHIVES);
            if (archives.length == 0) {
                log.info("No app archives found at {} - nothing to deploy", APP_ARCHIVES);
                return;
            }
            for (Resource archive : archives) {
                try (InputStream in = archive.getInputStream();
                     ZipInputStream zip = new ZipInputStream(in)) {
                    repositoryService.createDeployment()
                            .name(archive.getFilename())
                            .tenantId(tenantId)
                            .enableDuplicateFiltering()
                            .addZipInputStream(zip)
                            .deploy();
                    log.info("Deployed {} under tenant '{}'", archive.getFilename(), tenantId);
                }
            }
        };
    }
}
