package com.ubs.wmi.workflow.core.service;

import java.util.Map;

import com.ubs.wmi.workflow.core.tenant.TenantResolver;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.engine.runtime.ProcessInstanceQuery;

/**
 * Tenant-scoped entry point for process operations.
 * <p>
 * On a shared Flowable schema the biggest risk is a query that forgets its tenant filter
 * and returns another application's instances. Make it a review rule that application code
 * uses this facade rather than RuntimeService directly, and the leak cannot happen by
 * omission.
 */
public class PlatformProcessFacade {

    private final RuntimeService runtimeService;
    private final TenantResolver tenantResolver;

    public PlatformProcessFacade(RuntimeService runtimeService, TenantResolver tenantResolver) {
        this.runtimeService = runtimeService;
        this.tenantResolver = tenantResolver;
    }

    public ProcessInstance start(String processDefinitionKey, String businessKey,
                                 Map<String, Object> variables) {
        return runtimeService.createProcessInstanceBuilder()
                .processDefinitionKey(processDefinitionKey)
                .businessKey(businessKey)
                .variables(variables)
                .tenantId(tenantResolver.currentTenantId())
                .fallbackToDefaultTenant()
                .start();
    }

    /** Query pre-filtered to the current tenant; add further criteria on top. */
    public ProcessInstanceQuery query() {
        return runtimeService.createProcessInstanceQuery()
                .processInstanceTenantId(tenantResolver.currentTenantId());
    }

    public RuntimeService unsafeRuntimeService() {
        return runtimeService;
    }
}
