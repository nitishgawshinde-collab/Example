package com.ubs.wmi.workflow.core.tenant;

import com.ubs.wmi.workflow.core.config.WorkflowPlatformProperties;
import com.ubs.wmi.workflow.core.service.PlatformProcessFacade;
import com.ubs.wmi.workflow.core.service.PlatformTaskFacade;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@EnableConfigurationProperties(WorkflowPlatformProperties.class)
public class TenantAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(TenantResolver.class)
    public TenantResolver tenantResolver(WorkflowPlatformProperties properties) {
        return new FixedTenantResolver(properties.resolvedTenantId());
    }

    @Bean
    @ConditionalOnBean(RuntimeService.class)
    @ConditionalOnMissingBean(PlatformProcessFacade.class)
    public PlatformProcessFacade platformProcessFacade(RuntimeService runtimeService,
                                                       TenantResolver tenantResolver) {
        return new PlatformProcessFacade(runtimeService, tenantResolver);
    }

    @Bean
    @ConditionalOnBean(TaskService.class)
    @ConditionalOnMissingBean(PlatformTaskFacade.class)
    public PlatformTaskFacade platformTaskFacade(TaskService taskService,
                                                 TenantResolver tenantResolver) {
        return new PlatformTaskFacade(taskService, tenantResolver);
    }
}
