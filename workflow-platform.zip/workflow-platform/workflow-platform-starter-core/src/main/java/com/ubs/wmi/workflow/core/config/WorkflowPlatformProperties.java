package com.ubs.wmi.workflow.core.config;

import java.util.ArrayList;
import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;

/**
 * Single source of identity for a workflow application.
 * <p>
 * {@code appKey} drives the Flowable tenant id, the async job category and the
 * Liquibase context, so one property keeps all three isolation mechanisms aligned.
 */
@ConfigurationProperties(prefix = "wmi.workflow")
@Validated
public class WorkflowPlatformProperties {

    /** Unique key for this workflow application, e.g. "ticketing", "onboarding". */
    @NotBlank
    @Pattern(regexp = "[a-z][a-z0-9-]{2,30}",
             message = "app-key must be lowercase kebab-case, 3-31 chars")
    private String appKey;

    /** Flowable tenant id for deployments and queries. Defaults to appKey. */
    private String tenantId;

    /**
     * Let the engine create/update the Flowable schema. Keep {@code true} for local
     * development and {@code false} everywhere else, where schema is owned by the
     * release pipeline. On a shared database this must be false in production:
     * concurrent engines racing to upgrade the same schema is a known failure mode.
     */
    private boolean databaseSchemaUpdate = true;

    private final Jobs jobs = new Jobs();

    public static class Jobs {

        /** Run the async executor in this instance. */
        private boolean asyncExecutorEnabled = true;

        /**
         * Job categories this instance is allowed to acquire. Defaults to [appKey].
         * This is what stops application A from picking up application B's jobs when
         * they share a Flowable schema.
         */
        private List<String> enabledCategories = new ArrayList<>();

        /** Seconds the executor waits after a failed job acquisition cycle. */
        private int failedJobWaitTime = 30;

        public boolean isAsyncExecutorEnabled() { return asyncExecutorEnabled; }
        public void setAsyncExecutorEnabled(boolean v) { this.asyncExecutorEnabled = v; }
        public List<String> getEnabledCategories() { return enabledCategories; }
        public void setEnabledCategories(List<String> v) { this.enabledCategories = v; }
        public int getFailedJobWaitTime() { return failedJobWaitTime; }
        public void setFailedJobWaitTime(int v) { this.failedJobWaitTime = v; }
    }

    /** Effective tenant id: explicit value if set, otherwise the app key. */
    public String resolvedTenantId() {
        return StringUtils.hasText(tenantId) ? tenantId : appKey;
    }

    /** Effective job categories: explicit list if set, otherwise [appKey]. */
    public List<String> resolvedJobCategories() {
        List<String> configured = jobs.getEnabledCategories();
        return (configured == null || configured.isEmpty()) ? List.of(appKey) : configured;
    }

    public String getAppKey() { return appKey; }
    public void setAppKey(String appKey) { this.appKey = appKey; }
    public String getTenantId() { return tenantId; }
    public void setTenantId(String tenantId) { this.tenantId = tenantId; }
    public boolean isDatabaseSchemaUpdate() { return databaseSchemaUpdate; }
    public void setDatabaseSchemaUpdate(boolean v) { this.databaseSchemaUpdate = v; }
    public Jobs getJobs() { return jobs; }
}
