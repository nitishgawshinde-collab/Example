-- One schema per workflow application on a single shared PostgreSQL database.
-- This is the recommended isolation level: same infrastructure and connection pooling
-- story, but each application owns its Flowable tables outright.
CREATE SCHEMA IF NOT EXISTS ticketing AUTHORIZATION workflow;
CREATE SCHEMA IF NOT EXISTS onboarding AUTHORIZATION workflow;
