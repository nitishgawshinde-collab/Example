# Workflow Platform - architecture notes

## Shape

One Spring Boot service per workflow application, each embedding the Flowable engine and
consuming the platform through Spring Boot starters. Chosen because the applications are
both model-driven and heavy on custom Java: models and the Java they call ship together,
each application scales and releases independently, and nothing has to be side-loaded onto
a shared cluster classpath.

The alternative shape - one Flowable Work cluster with multiple app deployments - is
operationally simpler when applications are mostly model-driven with thin Java. It is worth
revisiting if the custom-code footprint shrinks.

## Database isolation: pick one, deliberately

| Option | Isolation | Cost |
|---|---|---|
| Schema per app, one PostgreSQL database *(default here)* | Full: separate ACT_ tables | Slightly more DDL management |
| Fully shared Flowable schema | None by default | Requires job categories AND tenant filters everywhere |

The sample application uses schema-per-app (`currentSchema=ticketing`). Job categories and
tenant filtering are still configured on top, as defence in depth and because they are what
you need the day someone consolidates schemas.

## The four things that bite on a shared database

1. **Cross-application job acquisition.** Application A's async executor acquires application
   B's job and fails with `ClassNotFoundException` on a delegate it does not have. Mitigated
   by `enabledJobCategories` in `WorkflowEngineAutoConfiguration` plus a job category on
   every async element in every model. Add a CI check that scans exported models.
2. **Schema version lock-step.** All applications sharing a schema must upgrade Flowable
   together; the engine validates schema version at startup. The BOM enforces the version at
   build time, but the release train has to match.
3. **Query leakage.** Any query missing its tenant filter returns a neighbour's data. Mitigated
   by `PlatformProcessFacade` / `PlatformTaskFacade` - make direct engine service use a
   review exception rather than the norm.
4. **Concurrent schema upgrades.** Two engines with `databaseSchemaUpdate=true` racing on one
   schema. Mitigated by `wmi.workflow.database-schema-update: false` in every shared
   environment; DDL belongs to the release pipeline.

## Liquibase convention

`db.changelog-master.yaml` in the platform runs the platform baseline, then `includeAll` over
`db/changelog/app/`. Applications drop changesets there and need no property override. The
`appKey` parameter and Liquibase context are injected by
`PlatformDefaultsEnvironmentPostProcessor`, so an application changeset can be tagged and
parameterised without extra configuration.

## Override model

Every platform bean is `@ConditionalOnMissingBean` (or conditional on bean name). An
application overrides by declaring its own bean - for example a `TenantResolver` that reads a
JWT claim if that application is itself multi-tenant. Platform defaults are contributed at the
lowest property precedence, so application YAML, environment variables and Key Vault always
win.

## Build order for the platform team

1. `workflow-platform-test` two-engine isolation test against one schema - prove the job
   category configuration before any application depends on it.
2. Enforcer rules banning Flowable/Spring version declarations inside applications.
3. A Maven archetype (`platform-app-archetype`) so new applications start compliant.
