package com.ubs.wmi.workflow.azure;

import java.io.InputStream;
import java.util.UUID;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.models.BlobHttpHeaders;

/**
 * Minimal content abstraction over Azure Blob Storage.
 * <p>
 * Deliberately small: if you move to Flowable Work's own ContentStorage SPI, implement that
 * interface and delegate to this class rather than rewriting the storage logic.
 */
public class BlobContentStore {

    private final BlobContainerClient containerClient;
    private final String pathPrefix;

    public BlobContentStore(BlobContainerClient containerClient, String pathPrefix) {
        this.containerClient = containerClient;
        this.pathPrefix = (pathPrefix == null || pathPrefix.isBlank()) ? "" : pathPrefix + "/";
    }

    /** @return the storage id to persist against the case/process variable. */
    public String store(String tenantId, String fileName, String contentType,
                        InputStream data, long length) {
        String id = pathPrefix + tenantId + "/" + UUID.randomUUID() + "/" + fileName;
        BlobClient blob = containerClient.getBlobClient(id);
        blob.upload(data, length, true);
        if (contentType != null) {
            blob.setHttpHeaders(new BlobHttpHeaders().setContentType(contentType));
        }
        return id;
    }

    public InputStream retrieve(String storageId) {
        return containerClient.getBlobClient(storageId).openInputStream();
    }

    public boolean delete(String storageId) {
        return containerClient.getBlobClient(storageId).deleteIfExists();
    }
}
