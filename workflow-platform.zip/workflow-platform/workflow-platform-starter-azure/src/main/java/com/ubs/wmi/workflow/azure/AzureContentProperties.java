package com.ubs.wmi.workflow.azure;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "wmi.workflow.azure.content")
public class AzureContentProperties {

    /** Enable the Blob-backed content store. */
    private boolean enabled = true;

    /**
     * Blob container for this application's documents. Defaults to
     * "flowable-content-<appKey>". Keeping case documents out of PostgreSQL from day one
     * avoids a painful migration later.
     */
    private String container;

    /** Optional logical folder prefix inside the container. */
    private String pathPrefix = "";

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean v) { this.enabled = v; }
    public String getContainer() { return container; }
    public void setContainer(String v) { this.container = v; }
    public String getPathPrefix() { return pathPrefix; }
    public void setPathPrefix(String v) { this.pathPrefix = v; }
}
