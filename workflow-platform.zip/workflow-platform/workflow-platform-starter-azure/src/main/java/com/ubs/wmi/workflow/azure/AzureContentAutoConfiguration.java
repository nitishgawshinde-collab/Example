package com.ubs.wmi.workflow.azure;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.ubs.wmi.workflow.core.config.WorkflowPlatformProperties;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.util.StringUtils;

/**
 * Wires a per-application Blob container. Authentication comes from Spring Cloud Azure:
 * in Azure use managed identity (no secrets in config), locally use a connection string
 * or Azurite.
 */
@AutoConfiguration
@ConditionalOnClass(BlobServiceClient.class)
@ConditionalOnProperty(prefix = "wmi.workflow.azure.content", name = "enabled",
                       havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties({AzureContentProperties.class, WorkflowPlatformProperties.class})
public class AzureContentAutoConfiguration {

    @Bean
    @ConditionalOnBean(BlobServiceClient.class)
    @ConditionalOnMissingBean(BlobContentStore.class)
    public BlobContentStore blobContentStore(BlobServiceClient blobServiceClient,
                                             AzureContentProperties contentProperties,
                                             WorkflowPlatformProperties platformProperties) {
        String container = StringUtils.hasText(contentProperties.getContainer())
                ? contentProperties.getContainer()
                : "flowable-content-" + platformProperties.getAppKey();

        BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(container);
        return new BlobContentStore(containerClient, contentProperties.getPathPrefix());
    }
}
