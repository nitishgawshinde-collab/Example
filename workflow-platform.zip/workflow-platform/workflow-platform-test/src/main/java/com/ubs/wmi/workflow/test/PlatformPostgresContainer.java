package com.ubs.wmi.workflow.test;

import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;

/**
 * Single reusable PostgreSQL container for the whole test JVM.
 * <p>
 * Every workflow application tests against real PostgreSQL rather than H2: Flowable's
 * schema, Liquibase and the locking behaviour of the job executor all differ enough from
 * H2 that green in-memory tests tell you very little.
 */
public final class PlatformPostgresContainer {

    private static final DockerImageName IMAGE = DockerImageName.parse("postgres:16-alpine");

    private static PostgreSQLContainer<?> instance;

    private PlatformPostgresContainer() {
    }

    public static synchronized PostgreSQLContainer<?> getInstance() {
        if (instance == null) {
            instance = new PostgreSQLContainer<>(IMAGE)
                    .withDatabaseName("wmi_workflow")
                    .withUsername("workflow")
                    .withPassword("workflow")
                    .withReuse(true);
            instance.start();
        }
        return instance;
    }
}
