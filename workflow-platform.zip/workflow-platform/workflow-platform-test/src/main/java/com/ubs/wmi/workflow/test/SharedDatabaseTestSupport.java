package com.ubs.wmi.workflow.test;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Helpers for the tests that actually matter on a shared database.
 * <p>
 * The isolation test every workflow app should run: boot two application contexts with
 * different app keys against the same schema, start an async job in each, and assert that
 * neither engine acquired the other's job. That is the failure you cannot afford to
 * discover in UAT, because it surfaces as a ClassNotFoundException on a delegate that
 * simply is not on the other application's classpath.
 */
public final class SharedDatabaseTestSupport {

    private SharedDatabaseTestSupport() {
    }

    /** Creates a schema so each application can own its Flowable tables. */
    public static void createSchema(DataSource dataSource, String schema) {
        new JdbcTemplate(dataSource).execute("CREATE SCHEMA IF NOT EXISTS " + schema);
    }

    /** Counts jobs currently visible in the shared schema for a given category. */
    public static int countJobsByCategory(DataSource dataSource, String category) {
        Integer count = new JdbcTemplate(dataSource).queryForObject(
                "SELECT COUNT(*) FROM ACT_RU_JOB WHERE CATEGORY_ = ?", Integer.class, category);
        return count == null ? 0 : count;
    }

    /** Fails loudly if an engine has picked up work that is not its own. */
    public static void assertNoForeignJobsAcquired(DataSource dataSource,
                                                   String ownCategory,
                                                   String foreignCategory) {
        Integer lockedForeign = new JdbcTemplate(dataSource).queryForObject(
                "SELECT COUNT(*) FROM ACT_RU_JOB WHERE CATEGORY_ = ? AND LOCK_OWNER_ IS NOT NULL",
                Integer.class, foreignCategory);
        if (lockedForeign != null && lockedForeign > 0) {
            throw new AssertionError("Engine for category '" + ownCategory
                    + "' acquired " + lockedForeign + " job(s) belonging to '" + foreignCategory
                    + "'. Job category isolation is not configured correctly.");
        }
    }
}
