package com.ubs.wmi.ticketing;

import com.ubs.wmi.workflow.core.service.PlatformProcessFacade;
import com.ubs.wmi.workflow.core.tenant.TenantResolver;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.task.api.Task;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.test.context.ActiveProfiles;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import com.ubs.wmi.workflow.core.service.PlatformTaskFacade;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Testcontainers
@ActiveProfiles("test")
class TicketingApplicationTests {

    @Container
    @ServiceConnection
    static PostgreSQLContainer<?> postgres =
            new PostgreSQLContainer<>("postgres:16-alpine")
                    .withDatabaseName("wmi_workflow")
                    .withUsername("workflow")
                    .withPassword("workflow");

    @Autowired PlatformProcessFacade processFacade;
    @Autowired PlatformTaskFacade taskFacade;
    @Autowired TenantResolver tenantResolver;
    @Autowired RepositoryService repositoryService;

    @Test
    void processIsDeployedAndRunsUnderTheApplicationTenant() {
        assertThat(repositoryService.createProcessDefinitionQuery()
                .processDefinitionKey("ticketHandling").count()).isEqualTo(1);

        ProcessInstance instance = processFacade.start("ticketHandling", "TCK-1",
                Map.of("ticketRef", "TCK-1", "category", "payments", "raisedBy", "tester"));

        assertThat(instance).isNotNull();
        assertThat(tenantResolver.currentTenantId()).isEqualTo("ticketing");

        Task task = taskFacade.query().processInstanceId(instance.getId()).singleResult();
        assertThat(task).isNotNull();
        assertThat(task.getName()).isEqualTo("Resolve ticket");
        assertThat(task.getAssignee()).isEqualTo("payments-ops");
    }

    @Test
    void queriesAreScopedToThisApplicationTenant() {
        // The facade always applies the tenant filter, so another application's instances
        // in a shared schema can never appear here.
        assertThat(processFacade.query().list())
                .allSatisfy(pi -> assertThat(pi.getTenantId()).isEqualTo("ticketing"));
    }
}
