package com.ubs.wmi.ticketing.delegate;

import com.ubs.wmi.ticketing.service.TicketService;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Application-owned business logic. This is exactly the code that must NOT be acquirable by
 * another application's job executor: it only exists on this service's classpath.
 */
@Component("assignTicketDelegate")
public class AssignTicketDelegate implements JavaDelegate {

    private static final Logger log = LoggerFactory.getLogger(AssignTicketDelegate.class);

    private final TicketService ticketService;

    public AssignTicketDelegate(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @Override
    public void execute(DelegateExecution execution) {
        String ticketRef = (String) execution.getVariable("ticketRef");
        String assignee = ticketService.determineAssignee(
                (String) execution.getVariable("category"));

        execution.setVariable("assignee", assignee);
        log.info("Assigned ticket {} to {} (tenant={})",
                ticketRef, assignee, execution.getTenantId());
    }
}
