package com.ubs.wmi.ticketing.service;

import java.util.Map;

import com.ubs.wmi.workflow.core.service.PlatformProcessFacade;
import org.flowable.engine.runtime.ProcessInstance;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TicketService {

    private static final String PROCESS_KEY = "ticketHandling";

    private final PlatformProcessFacade processFacade;

    public TicketService(PlatformProcessFacade processFacade) {
        this.processFacade = processFacade;
    }

    /** Starts a ticket process; tenant is applied by the platform facade. */
    @Transactional
    public String raiseTicket(String ticketRef, String category, String raisedBy) {
        ProcessInstance instance = processFacade.start(PROCESS_KEY, ticketRef,
                Map.of("ticketRef", ticketRef,
                       "category", category,
                       "raisedBy", raisedBy));
        return instance.getId();
    }

    /** Placeholder for the real routing rules (DMN table, org lookup, etc.). */
    public String determineAssignee(String category) {
        if (category == null) {
            return "triage-queue";
        }
        return switch (category.toLowerCase()) {
            case "payments" -> "payments-ops";
            case "onboarding" -> "client-onboarding";
            default -> "triage-queue";
        };
    }
}
