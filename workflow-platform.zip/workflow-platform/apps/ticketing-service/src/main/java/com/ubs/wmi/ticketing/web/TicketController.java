package com.ubs.wmi.ticketing.web;

import java.util.List;
import java.util.Map;

import com.ubs.wmi.ticketing.service.TicketService;
import com.ubs.wmi.workflow.core.service.PlatformTaskFacade;
import org.flowable.task.api.Task;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    private final TicketService ticketService;
    private final PlatformTaskFacade taskFacade;

    public TicketController(TicketService ticketService, PlatformTaskFacade taskFacade) {
        this.ticketService = ticketService;
        this.taskFacade = taskFacade;
    }

    public record RaiseTicketRequest(String ticketRef, String category, String raisedBy) {}

    @PostMapping
    public ResponseEntity<Map<String, String>> raise(@RequestBody RaiseTicketRequest request) {
        String processInstanceId = ticketService.raiseTicket(
                request.ticketRef(), request.category(), request.raisedBy());
        return ResponseEntity.ok(Map.of(
                "processInstanceId", processInstanceId,
                "ticketRef", request.ticketRef()));
    }

    /** Tenant filter is applied inside the facade, so it cannot be forgotten here. */
    @GetMapping("/tasks")
    public List<Map<String, Object>> openTasks() {
        return taskFacade.query().orderByTaskCreateTime().desc().list().stream()
                .map(TicketController::toDto)
                .toList();
    }

    @PostMapping("/tasks/{taskId}/complete")
    public ResponseEntity<Void> complete(@PathVariable String taskId,
                                         @RequestBody(required = false) Map<String, Object> variables) {
        taskFacade.complete(taskId, variables == null ? Map.of() : variables);
        return ResponseEntity.noContent().build();
    }

    private static Map<String, Object> toDto(Task task) {
        return Map.of(
                "id", task.getId(),
                "name", String.valueOf(task.getName()),
                "assignee", String.valueOf(task.getAssignee()),
                "created", String.valueOf(task.getCreateTime()));
    }
}
