# WMI Workflow Platform

Parent project for building multiple Spring Boot + Flowable workflow applications on shared
infrastructure (PostgreSQL, Azure, Elasticsearch). Applications contribute models and business
logic; everything else arrives through starters.

## Import into IntelliJ

1. Unzip, then **File > Open** and select the top-level `pom.xml` (choose *Open as Project*).
2. Set the Project SDK to **JDK 17**.
3. IntelliJ indexes the six modules automatically. Enable annotation processing
   (*Settings > Build > Compiler > Annotation Processors*) so the Spring configuration
   processor generates metadata for `wmi.workflow.*` autocompletion.
4. `docker compose up -d` for PostgreSQL + Elasticsearch.
5. Run `com.ubs.wmi.ticketing.TicketingApplication` (port 8081).

```bash
mvn clean install                      # build platform + sample app
mvn -pl apps/ticketing-service test    # Testcontainers integration test (Docker required)
```

## Modules

| Module | Purpose |
|---|---|
| `workflow-platform-parent` | Version management, enforcer rules, plugin config |
| `workflow-platform-bom` | Importable BOM for apps that cannot use the parent POM |
| `workflow-platform-starter-core` | Engine policy, tenant resolution, job-category isolation, Liquibase master changelog |
| `workflow-platform-starter-search` | Elasticsearch index naming and isolation strategy |
| `workflow-platform-starter-azure` | Blob-backed content store, Key Vault, managed identity |
| `workflow-platform-test` | Shared Testcontainers support, shared-database assertions |
| `apps/ticketing-service` | Reference application - copy this to start a new workflow app |

## What a new workflow application has to do

```xml
<parent>
  <groupId>com.ubs.wmi.workflow</groupId>
  <artifactId>workflow-platform-parent</artifactId>
  <version>1.0.0-SNAPSHOT</version>
</parent>
<dependencies>
  <dependency>
    <groupId>com.ubs.wmi.workflow</groupId>
    <artifactId>workflow-platform-starter-core</artifactId>
    <version>${project.version}</version>
  </dependency>
</dependencies>
```

```yaml
wmi:
  workflow:
    app-key: onboarding          # drives tenant id, job category and Liquibase context
spring:
  datasource:
    url: jdbc:postgresql://host:5432/wmi_workflow?currentSchema=onboarding
```

Then add:

- `src/main/resources/apps/*.zip` - Flowable Design exports (deployed under the app tenant), or
  plain `processes/*.bpmn20.xml` for hand-written models
- `src/main/resources/db/changelog/app/*.yaml` - application tables, picked up automatically
- `src/main/java/**` - delegates, services, REST controllers

## Before you go to production

Read `docs/ARCHITECTURE.md`. The short version:

- Set `wmi.workflow.database-schema-update: false` in every shared environment.
- Give every async element in every model a job category equal to the app key, and add a CI
  check that verifies it. Without this, one application's executor will acquire another's jobs.
- Use `PlatformProcessFacade` / `PlatformTaskFacade` rather than `RuntimeService` /
  `TaskService` directly, so no query can lose its tenant filter.
- Build the two-engine isolation test in `workflow-platform-test` before any second
  application ships.

## Versions - verify before go-live

`pom.xml` currently pins **open-source Flowable 7.0.1 and Spring Boot 3.3.4** so the project
resolves from Maven Central and you can explore it immediately. For Flowable Work 3.17
Enterprise:

- Swap the `org.flowable:flowable-bom` import for your enterprise platform BOM and point the
  `flowable-enterprise` repository at your Artifactory proxy (both marked with `ENTERPRISE:`
  comments in the parent POM).
- Replace the `flowable-spring-boot-starter-*` dependencies in `starter-core` with the
  Flowable Work starters.
- Confirm the Spring Boot version certified for your Flowable release and set it in
  `spring-boot.version`.
- Check `setEnabledJobCategories` and the model-level job-category attribute name against your
  Flowable version's API and XSD - these are the two places the sketch is most likely to need
  adjusting.

This repository was scaffolded without a build run; treat your first `mvn clean install` as
the real verification.
