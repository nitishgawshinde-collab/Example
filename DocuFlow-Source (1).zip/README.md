# DocuFlow — business approval prototype

Open `dist/index.html` in a modern desktop browser, or open the self-contained
`DocuFlow-Prototype.html` supplied alongside the source ZIP. No build or server
is required. All scripts, styles, and the AG Grid Community bundle are local.

## Scope

Vanilla HTML, CSS, JavaScript; a banking document workspace using fictional data.
The red, black, and gray visual language follows the supplied references without
using bank logos or representing this as an official bank application.

Implemented screens: dashboard; cases and workflows; case detail and stepper;
my tasks; file cabinets; document tray; search dialogs; connected applications;
audit trail; settings. AG Grid supports sorting, column filters, resizing,
pagination, visibility controls, and row navigation. Toolbar CSV export respects
external search/view/business-group filters and AG Grid column filters and sorting.

## Business review walkthrough (10 minutes)

1. Start on My dashboard. Review portfolio counts, monthly illustrative chart,
   status distribution, cases, recent activity, and business-group workloads.
2. Select Awaiting review, search Northbridge, and open its case. Inspect its
   four documents, source provenance, and workflow stages.
3. Open an individual document. Review index fields, specimen preview, and
   version history. Download specimen produces a clearly labeled text record.
4. Approve compliance, then authorize account opening. Verify status, task list,
   dashboard counts, and audit trail update.
5. Use Retrieve from Hive. Search Alpine and use its authoritative client record.
   Golden-source fields are read-only; choose the account type and create a case.
6. Begin document collection. Upload a sample document to the tray, then Index &
   store it. Open its specimen and verify it. Repeat for all four required types.
   Submission to compliance is blocked until the required evidence is verified.
7. Request information with a reason; resume the held case and continue.
8. Open Connected applications and review the Compliance Hub exception.
9. Use Workspace settings to reset the local demonstration.

## Data boundaries

Hive is the bank's golden source of client/business data, consolidated from
business-group applications. The prototype represents a dated read-only snapshot.
A future backend should access Hive through approved integration services and
maintain a low-latency operational projection. It should not issue Hive queries
from the browser. Bank applications publish data through the integration layer;
this workspace submits correction requests to the owning source application.

Golden-source record identity, source application, snapshot time, and reconciliation
status should be retained. Process state, task assignments, decisions and local
workflow attributes belong to the operational system. Do not silently overwrite
golden-source attributes from workflow forms. Implement idempotent events,
reconciliation, source precedence, and a defined eventual-consistency contract.
Actual document bytes may reside outside Hive: resolve storage references through
the content backend, with Azure Blob Storage as the proposed document store.

## Reuse in React 19

The prototype is framework-independent, not a finished React application.

| File | React reuse approach |
| --- | --- |
| dist/styles.css | Reuse tokens, spacing, palette, responsive breakpoints; split component styles as desired. |
| dist/data.js | Retain fictional fixtures for Storybook/demo mode; replace runtime reads with API DTOs. |
| dist/domain.js | Extract exports into a domain module; expose state through hooks/context or an external store. Replace localStorage with authenticated APIs. |
| dist/grid.js | Reuse column definitions and theme parameters with AgGridReact; replace DOM cell renderers with React components. |
| dist/app.js | Convert screen renderers into components and event delegation into typed callbacks; use a router for screen state. |
| dist/index.html | Use its semantic shell, navigation, dialogs, and landmark structure as component boundaries. |

Suggested component boundaries: AppShell, WorkspaceNavigation, DashboardPage,
PortfolioStats, WorkflowVolumeChart, CaseStatusChart, CasesGrid, CaseWorkspace,
WorkflowStepper, DocumentTable, DocumentViewer, IndexFieldsForm, DocumentTray,
HiveRecordPicker, CreateCaseDialog, DecisionDialog, ConnectionsPage, AuditTrail.

Suggested API boundaries: case queries/creation; document ingest/version/verify;
workflow task actions; golden-source search and snapshot retrieval; correction
requests; integration reconciliation; audit queries. Keep backend authorization
and validation authoritative. No browser-side approval or verification can be
trusted in production.

## AG Grid

Bundled: AG Grid Community 34.3.1 (MIT). Version is pinned for reproducibility.
Enterprise key and modules were not provided; no Enterprise license was embedded.
This does not validate the bank's existing license entitlement or expiry.
For React production, align ag-grid-community, ag-grid-enterprise, and
ag-grid-react to the same bank-approved version; register only the licensed
modules required. Add the bank's key using the supported license initialization.
Enterprise row grouping, master/detail, server-side row model, Excel export, and
advanced filter are candidates, not implemented features of this prototype.
CSV export is implemented. The normal HTML table is a fallback if AG Grid fails.
Retain the included AG Grid license notice when redistributing its bundle.

## Deliberate simulation limits

- Fixed fictional identity Alex Morgan. No SSO, bank access, authorization, live
  Flowable, Hive, Azure, email, malware scanning, OCR, or account provisioning.
- File names only are retained; selected file contents are neither uploaded nor
  stored. The preview is a generated specimen, not a PDF viewer.
- Local browser storage is demonstration state; it is not shared or durable bank
  storage. Never enter real personal or bank data.
- The chart is labeled illustrative. Portfolio metrics derive from local records.
- Document versions preserve demo metadata only, not the original binary.
- A case can demonstrate all approval steps under one identity. Production must
  enforce maker/checker separation, entitlements, task ownership, and immutable
  decision evidence against exact document versions.
- Audit entries are editable browser data, not compliance-grade evidence.
- Retention, legal holds, signatures, and Office coauthoring require separate work.

## Production handoff gates

Confirm Flowable Enterprise 2025.2 service pack, JDK 17/Spring compatibility,
React 19 renderer support, and AG Grid entitlement. Agree document/metadata
ownership, Hive source contracts, API schemas, SLA rules, delegated permissions,
version-pinned approvals, accessibility acceptance, real upload/preview handling,
and operational recovery. Review the prototype with representative business users
before finalizing screen specifications.

## Validation

JavaScript syntax, AG Grid initialization, DOM interactions, and domain transitions are checked, including required-document
gates, duplicate active-case prevention, hold/resume, and completed-case protection.
The static-site workflow has no supported interactive browser preview in this
execution environment. Browser visual/device QA must be completed before production;
this deliverable is an approval prototype, not a production release.

## Enhanced document lifecycle and Archive

- Workspace > Archive shows completed cases ready for archival and already
  archived cases. Search by client/case; archive a completed case with a reason.
- Archived cases are removed from operational case grids. Document records and
  case history remain readable. Archive is not deletion; no automatic disposal
  or production retention period is implied. A sample archived case is included.
- Open a document from a file cabinet or case to edit its title/cabinet, edit
  demonstration specimen text, explicitly upload a newer version, or add a
  typed demonstration signature. Protected client/case/type fields are read-only.
- These edits create a version snapshot. The prototype preserves previous demo
  metadata, specimen text, and signature evidence, not actual file bytes.
- Only verified versions can receive a demonstration signature. Revised versions
  clear the current signature, require verification, and send cases past document
  collection back for review. Historical decisions/signatures remain preserved.
- Completed and archived records cannot be revised or signed. Real post-completion
  amendments should use a separately authorized amendment workflow.
- The signature has no cryptographic or legally validated signing capability.
  Integrate an approved signing provider, signer authentication, certificates where
  applicable, webhook verification, and durable evidence before production.
- Real Word/PDF editing still needs an editor integration. The working sample-text
  editor demonstrates the version lifecycle; it does not edit uploaded binary files.
- Added domain and DOM checks verify archival guards, read-only UI, signature
  binding, history preservation, invalidation on revision, and renewed review.
