REVOKE CREATE ON SCHEMA public FROM PUBLIC;
CREATE ROLE example_app LOGIN PASSWORD 'example_local';
CREATE SCHEMA example_workflow AUTHORIZATION example_app;
ALTER ROLE example_app IN DATABASE workflows SET search_path TO example_workflow;
