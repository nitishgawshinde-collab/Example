package com.yourcompany.applications.workflow;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

/** Local demonstration override; production uses the starter's JWT policy. */
@Configuration(proxyBeanMethods = false)
@Profile("local")
public class LocalSecurityConfiguration {
    @Bean
    UserDetailsService localUsers() {
        return new InMemoryUserDetailsManager(User.withUsername("demo")
            .password("{noop}local-only").roles("USER").build());
    }
    @Bean
    SecurityFilterChain localSecurity(HttpSecurity http) throws Exception {
        return http.sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth.requestMatchers("/actuator/health", "/actuator/health/**")
                .permitAll().anyRequest().authenticated())
            .httpBasic(Customizer.withDefaults()).build();
    }
}
