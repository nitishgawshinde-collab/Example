package com.yourcompany.applications.workflow;

import org.flowable.engine.RuntimeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import static org.assertj.core.api.Assertions.assertThat;

/** Explicit opt-in: needs local PostgreSQL and the organization's Flowable license. */
@EnabledIfSystemProperty(named = "workflow.runtime.tests", matches = "true")
@SpringBootTest
@ActiveProfiles("local")
class WorkflowRuntimeTest {
    @Autowired RuntimeService runtime;
    @Test
    void executesTheFirstProcess() {
        var process = runtime.startProcessInstanceByKey("firstWorkflow");
        assertThat(process.isEnded()).isTrue();
    }
}
