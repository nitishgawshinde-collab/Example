# example-workflow

Independent consumer of `commons-workflow`. This directory is copied/generated into its own repository;
it is not part of the platform Maven reactor. Rename its artifact, package, process, schema and GitLab
project settings before building a real workflow. The generator handles basic names automatically.

## First run

1. Configure Maven to use `ci/maven-settings.xml` and supply Nexus group/read credentials to the Maven
   process. Your organization must already have published parent/starter version 1.0.0.
2. Put your valid Enterprise license at `~/.flowable/flowable.license`. Do not commit it.
3. Open `pom.xml` in IntelliJ with JDK 17 and reload Maven.
4. Run `docker compose up -d --wait` from this directory.
5. Run `WorkflowApplication` with argument `--spring.profiles.active=local` (or use the supplied run
   configuration). If IntelliJ chooses another module name, create a run configuration from the class.
6. Check `http://localhost:8080/actuator/health`. There is no business API yet.
7. Replace the start/end BPMN skeleton and add delegates, business services, APIs and migrations.

The local profile enables schema updates and Liquibase, uses a loopback-bound app and database,
and supplies a local Basic-auth override (`demo` / `local-only`). It is only for development.
The empty changelog is intentional: a new workflow owns its own table definitions. Add versioned
changesets and includes; do not edit migrations already applied to a database.

To execute the first BPMN skeleton through a Spring/Flowable runtime test:

```bash
mvn -s ci/maven-settings.xml -Dworkflow.runtime.tests=true test
```

This opt-in test requires running PostgreSQL and your Enterprise license. Ordinary `verify` compiles
it but skips execution. It is a real runtime check when enabled, not part of the default unit-only build.
The sample process ends immediately; replace the test when adding human tasks or async steps.

## Production inputs

Supply `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`, `WORKFLOW_SCHEMA`, and `JWT_ISSUER_URI`.
Do not activate the local profile. Provision the owned schema and run business/Flowable migrations
before startup: production defaults do not perform DDL. The JDBC Hikari schema is supplied centrally,
so a `currentSchema` URL parameter is not needed; if supplied separately, it must match.

Default JWT validation uses the configured issuer. Configure audience validation where your identity
provider issues tokens for multiple services. Define business authorization on your controllers/services;
authentication alone is not approval permission. Use TLS and your organization's secret delivery.
The platform's default policy only exposes `/api/**` plus health; extend it deliberately if needed.

## GitLab

Change `YOUR_GROUP/commons-workflow` in `.gitlab-ci.yml` to the shared project's actual path and pin
its include to an immutable published tag or commit. The reusable build job packages this application;
it does not deploy it or publish it to Nexus. Read-only Nexus credentials are sufficient for this job.
GitLab users triggering this pipeline need permission to read the included private project.

The standalone executable is `target/example-workflow-0.1.0-SNAPSHOT.jar`. For command-line use:

```bash
mvn -s ci/maven-settings.xml clean package
java -jar target/example-workflow-0.1.0-SNAPSHOT.jar --spring.profiles.active=local
```

Compose init SQL only runs on a new database volume. Provision additional schemas explicitly in
existing databases; do not delete a volume to apply a schema change.
