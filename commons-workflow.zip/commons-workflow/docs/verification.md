# Verification and first-release acceptance

## Performed in this session

- Parse every POM, IntelliJ configuration, and BPMN XML file.
- Parse shared and consumer GitLab YAML, application YAML and Compose YAML.
- Parse every Java file with the Java 17 compiler parser, without dependency type resolution.
- Verify that the Maven reactor publishes only the parent and starter, with version-linked consumers.
- Verify auto-configuration registration paths and shell/Python syntax.
- Generate a separate onboarding consumer and check the Maven parent is not relative to the shared repo.
- Confirm generator refuses an existing destination and inspect ZIP integrity.

## Not executed

Maven compilation/unit tests, GitLab CI lint/execution, Nexus resolution/deployment, PostgreSQL,
Flowable Enterprise startup/license validation, and JWT/Flowable web-security integration were not
executed. Maven and Docker are unavailable in the generation environment. The deliverable is a
source implementation with static validation, not a runtime-certified platform release.

## Organization acceptance sequence

1. Configure Nexus group and upstream Flowable credentials; resolve the POMs through that group.
2. Run `mvn -s ci/maven-settings.xml clean install` and inspect unit test results.
3. Build the independent template using `mvn -s ci/maven-settings.xml -f consumer-template/pom.xml clean verify`.
4. Start its PostgreSQL service and supply a Flowable license. Run its opt-in runtime test with
   `-Dworkflow.runtime.tests=true`; confirm the test is executed, not skipped.
5. Start without the local profile using your issuer and provisioned schema; verify authenticated API
   access, rejected invalid tokens, public health, and protected native Flowable paths. Check starter
   security chain ordering against your actual Enterprise artifacts; do not bypass errors with permit-all.
6. Lint both pipelines in your GitLab instance; verify branch/MR read-secret availability and protected
   publication rules. Publish the first reviewed tag and build a generated consumer with a clean Maven
   local repository to prove Nexus delivery rather than local reactor resolution.
7. Validate migrations, role permissions, and one real application through a version upgrade before
   broad adoption. Add organization-specific acceptance gates to the CI template as they become defined.
