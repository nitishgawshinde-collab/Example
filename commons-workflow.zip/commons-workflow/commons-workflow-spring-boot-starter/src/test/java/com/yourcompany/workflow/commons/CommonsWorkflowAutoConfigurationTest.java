package com.yourcompany.workflow.commons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import static org.assertj.core.api.Assertions.assertThat;

class CommonsWorkflowAutoConfigurationTest {
    private final ApplicationContextRunner runner = new ApplicationContextRunner()
        .withConfiguration(AutoConfigurations.of(ValidationAutoConfiguration.class, CommonsWorkflowAutoConfiguration.class));
    @Test
    void defaultIsAvailable() {
        runner.withPropertyValues("commons.workflow.schema=claims").run(context -> {
            assertThat(context).hasSingleBean(BusinessKeyGenerator.class);
            assertThat(context.getBean(BusinessKeyGenerator.class).nextKey()).hasSize(36);
        });
    }
    @Test
    void consumerBeanReplacesDefault() {
        runner.withPropertyValues("commons.workflow.schema=claims")
            .withBean(BusinessKeyGenerator.class, () -> () -> "custom-key").run(context -> {
                assertThat(context).hasSingleBean(BusinessKeyGenerator.class);
                assertThat(context.getBean(BusinessKeyGenerator.class).nextKey()).isEqualTo("custom-key");
            });
    }
    @Test
    void missingSchemaFailsEarly() { runner.run(context -> assertThat(context).hasFailed()); }
}
