package com.yourcompany.workflow.commons;

import java.util.concurrent.atomic.AtomicReference;
import jakarta.servlet.ServletException;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import static org.assertj.core.api.Assertions.*;

class CorrelationIdFilterTest {
    @Test
    void preservesValidIdAndCleansThreadContext() throws Exception {
        var request = new MockHttpServletRequest();
        request.addHeader(CorrelationIdFilter.HEADER, "request-123");
        var response = new MockHttpServletResponse();
        var captured = new AtomicReference<String>();
        new CorrelationIdFilter().doFilter(request, response, (req, res) -> captured.set(MDC.get("correlationId")));
        assertThat(captured.get()).isEqualTo("request-123");
        assertThat(response.getHeader(CorrelationIdFilter.HEADER)).isEqualTo("request-123");
        assertThat(MDC.get("correlationId")).isNull();
    }
    @Test
    void invalidInputIsReplacedAndContextRestoredAfterFailure() {
        var request = new MockHttpServletRequest();
        request.addHeader(CorrelationIdFilter.HEADER, "invalid value");
        var response = new MockHttpServletResponse();
        MDC.put("correlationId", "previous");
        try {
            assertThatThrownBy(() -> new CorrelationIdFilter().doFilter(request, response,
                (req, res) -> { throw new ServletException("test failure"); })).isInstanceOf(ServletException.class);
            assertThat(response.getHeader(CorrelationIdFilter.HEADER)).hasSize(36);
            assertThat(MDC.get("correlationId")).isEqualTo("previous");
        } finally { MDC.remove("correlationId"); }
    }
}
