package com.yourcompany.workflow.commons;

import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.core.env.MapPropertySource;
import org.springframework.mock.env.MockEnvironment;
import static org.assertj.core.api.Assertions.assertThat;

class CommonsDefaultsTest {
    @Test
    void consumerSettingsWinAndSchemaDefaultsResolve() {
        var environment = new MockEnvironment();
        environment.getPropertySources().addFirst(new MapPropertySource("consumer", Map.of(
            "commons.workflow.schema", "claims", "flowable.history-level", "full")));
        new CommonsDefaultsEnvironmentPostProcessor().postProcessEnvironment(environment, null);
        assertThat(environment.getProperty("flowable.history-level")).isEqualTo("full");
        assertThat(environment.getProperty("flowable.database-schema")).isEqualTo("claims");
        assertThat(environment.getProperty("spring.datasource.hikari.schema")).isEqualTo("claims");
        assertThat(environment.getProperty("spring.liquibase.enabled")).isEqualTo("false");
    }
}
