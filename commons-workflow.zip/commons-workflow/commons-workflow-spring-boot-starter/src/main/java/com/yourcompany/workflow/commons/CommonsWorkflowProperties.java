package com.yourcompany.workflow.commons;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Validated
@ConfigurationProperties("commons.workflow")
public class CommonsWorkflowProperties {
    @NotBlank
    @Pattern(regexp = "[a-z][a-z0-9_]{0,62}")
    private String schema;
    public String getSchema() { return schema; }
    public void setSchema(String schema) { this.schema = schema; }
}
