package com.yourcompany.workflow.commons;

@FunctionalInterface
public interface BusinessKeyGenerator {
    String nextKey();
}
