package com.yourcompany.workflow.commons;

import java.util.UUID;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@EnableConfigurationProperties(CommonsWorkflowProperties.class)
public class CommonsWorkflowAutoConfiguration {
    @Bean
    @ConditionalOnMissingBean(BusinessKeyGenerator.class)
    BusinessKeyGenerator businessKeyGenerator() {
        return () -> UUID.randomUUID().toString();
    }
}
