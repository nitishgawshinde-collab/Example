package com.yourcompany.workflow.commons;

import java.io.IOException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.core.Ordered;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.ResourcePropertySource;

/** Low-precedence defaults: consumer configuration, environment and CLI values win. */
public class CommonsDefaultsEnvironmentPostProcessor implements EnvironmentPostProcessor, Ordered {
    @Override
    public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
        try {
            environment.getPropertySources().addLast(new ResourcePropertySource(
                "commonsWorkflowDefaults", new ClassPathResource("commons-workflow-defaults.properties")));
        } catch (IOException ex) {
            throw new IllegalStateException("Cannot load commons-workflow defaults", ex);
        }
    }
    @Override
    public int getOrder() { return Ordered.LOWEST_PRECEDENCE; }
}
