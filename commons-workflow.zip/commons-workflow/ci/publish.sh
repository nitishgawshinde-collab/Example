#!/bin/sh
set -eu
mode=${1:?Use release or snapshot}
: "${NEXUS_DEPLOY_USERNAME:?Missing Nexus publishing credentials}"
: "${NEXUS_DEPLOY_PASSWORD:?Missing Nexus publishing credentials}"
version=$(mvn -q -ntp -s ci/maven-settings.xml -Dstyle.color=never help:evaluate -Dexpression=project.version -DforceStdout)
case "$mode" in
  release)
    : "${NEXUS_RELEASE_URL:?Missing release repository URL}"
    test "${CI_COMMIT_TAG:-}" = "v$version" || { echo 'Tag must equal v plus the POM version'; exit 1; }
    case "$version" in *SNAPSHOT*) echo 'Release cannot be a snapshot'; exit 1;; esac
    ;;
  snapshot)
    : "${NEXUS_SNAPSHOT_URL:?Missing snapshot repository URL}"
    case "$version" in *-SNAPSHOT) :;; *) echo 'Release POM on default branch: no snapshot publication'; exit 0;; esac
    ;;
  *) echo 'Use release or snapshot'; exit 1;;
esac
# Rebuild and run unit tests on this checkout; deployAtEnd publishes after reactor success.
mvn -B -ntp -s ci/maven-settings.xml clean deploy
