#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET
r = Path(__file__).resolve().parents[1]
ns = {"m": "http://maven.apache.org/POM/4.0.0"}
root = ET.parse(r / "pom.xml")
version = root.findtext("m:version", namespaces=ns)
assert root.findtext("m:artifactId", namespaces=ns) == "commons-workflow-parent"
assert root.findtext("m:properties/m:commons-workflow.version", namespaces=ns) == version
assert [e.text for e in root.findall("m:modules/m:module", ns)] == ["commons-workflow-spring-boot-starter"]
for module in ["commons-workflow-spring-boot-starter", "consumer-template"]:
    pom = ET.parse(r / module / "pom.xml")
    assert pom.findtext("m:parent/m:version", namespaces=ns) == version
consumer = ET.parse(r / "consumer-template/pom.xml")
assert consumer.find("m:parent/m:relativePath", ns) is not None
assert consumer.findtext("m:parent/m:relativePath", namespaces=ns) == ""
print("Two-artifact reactor and independent consumer version linkage: valid")
