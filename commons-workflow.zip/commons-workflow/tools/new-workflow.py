#!/usr/bin/env python3
"""Generate a separate repository directory; never overwrites an existing destination."""
import argparse
from pathlib import Path
import re
import shutil

parser = argparse.ArgumentParser()
parser.add_argument("name", help="Maven artifact name, e.g. onboarding-workflow")
parser.add_argument("destination", type=Path)
parser.add_argument("--gitlab-project", required=True, help="Path of the commons repo, e.g. platform/commons-workflow")
args = parser.parse_args()
if not re.fullmatch(r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*", args.name):
    parser.error("Name must use lowercase words separated by hyphens")
schema = args.name.replace("-", "_")
if len(schema) > 50:
    parser.error("Name must be at most 50 characters")
if not re.fullmatch(r"[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)+", args.gitlab_project):
    parser.error("Invalid GitLab project path")
if args.destination.exists():
    parser.error("Destination already exists; choose a new directory")
source = Path(__file__).resolve().parents[1] / "consumer-template"
shutil.copytree(source, args.destination, ignore=shutil.ignore_patterns("target", ".idea", ".git", ".m2"))
for path in args.destination.rglob("*"):
    if path.is_file():
        content = path.read_text()
        content = content.replace("example-workflow", args.name).replace("example_workflow", schema)
        content = content.replace("example_app", schema + "_app")
        content = content.replace("YOUR_GROUP/commons-workflow", args.gitlab_project)
        path.write_text(content)
print(f"Created {args.destination.resolve()}. Open its pom.xml in IntelliJ.")
