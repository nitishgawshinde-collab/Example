# commons-workflow

Internal workflow development platform. GitLab builds this repository and publishes exactly two
Maven artifacts to your organization's Nexus repository:

| Artifact | Type | Consumer usage |
| --- | --- | --- |
| `com.yourcompany.workflow:commons-workflow-parent:1.0.0` | POM | Maven parent |
| `com.yourcompany.workflow:commons-workflow-spring-boot-starter:1.0.0` | JAR | Dependency |

There is no onboarding application in the shared reactor. `consumer-template/` is a minimal
independent project skeleton, not a published module. `ci/consumer.gitlab-ci.yml` is a reusable
GitLab build definition, versioned with this repository. `tools/new-workflow.py` creates new
consumer directories without changing the shared platform.

## Platform baseline

Java 17, Spring Boot 3.5.12, Flowable Enterprise 3.17.15, PostgreSQL, Liquibase, Spring Security JWT,
and Actuator. The Enterprise/Boot pairing follows the 3.17.15 release notes. These are selected
baseline versions, not a claim of latest patch status. There is no community profile and no Azure
SDK dependency. Elasticsearch indexing is disabled by default; teams can enable it for required
Enterprise features with their patch's supported configuration.

## What a consumer receives

- Centrally pinned dependencies and Java/build conventions.
- Flowable Enterprise integration and auto-configuration.
- Shared PostgreSQL schema convention for Hikari, Flowable, Liquibase, and migration history.
- Production defaults that do not modify schemas on application startup.
- A conventional application changelog location, overridable with `spring.liquibase.change-log`.
- JWT authentication for `/api/**`, public health, and denial of other routes in the default policy.
- Health/info infrastructure, Problem Details support for Spring MVC errors, and correlation IDs.
- A replaceable `BusinessKeyGenerator` bean and application configuration override points.

Business workflow models, delegates, APIs, tables/migrations, business authorization, and external
integration behavior remain in consumer repositories. The starter intentionally does not invent
a universal workflow API. It does not provision databases, identity providers, or cloud resources.

## First-time organization setup

1. Replace `com.yourcompany` in POMs and Java packages with your approved group/package convention.
   Keep Java paths aligned with package names, including the template and auto-configuration entries.
   Alternatively, keep the sample coordinates for an initial evaluation.
2. Create a GitLab project named `commons-workflow` and push this directory there.
3. Configure Nexus: hosted Maven releases, hosted Maven snapshots, a Maven Central proxy, and an
   authenticated Flowable Enterprise proxy. Put all four in your organization Maven group. Nexus's
   Flowable upstream credentials must be set by your repository administrator; consumer teams should
   not need individual vendor tokens. Confirm your agreement permits this internal distribution.
4. Set the GitLab variables listed below. Protect release tags matching `v*` and your default branch.
5. Use the bundled Maven settings for local builds/IntelliJ and validate the baseline in your environment.
6. Push tag `v1.0.0` on the reviewed release commit. Successful verification precedes publication.

No remote GitLab project or Nexus artifact was created from this session. Your actual URLs,
credentials, namespace, GitLab permissions, and Flowable license were not supplied.

## GitLab and Nexus variables

| Variable | Use |
| --- | --- |
| `NEXUS_GROUP_URL` | Full group URL, e.g. `https://nexus.example.com/repository/maven-public/` |
| `NEXUS_READ_USERNAME`, `NEXUS_READ_PASSWORD` | Read-only group access, also used by consumer CI |
| `NEXUS_RELEASE_URL` | Hosted Maven release repository URL |
| `NEXUS_SNAPSHOT_URL` | Hosted Maven snapshot repository URL |
| `NEXUS_DEPLOY_USERNAME`, `NEXUS_DEPLOY_PASSWORD` | Publish access; only protected pipeline refs need these |

Mark passwords masked. Restrict publishing credentials to protected refs. Decide explicitly whether
read-only credentials may be used by your internal branch/MR pipelines; forks should not receive
organization credentials automatically. CI uses the Maven image `maven:3.9.9-eclipse-temurin-17`;
mirror/pin it according to organization policy if necessary.

All dependency and plugin requests go through the Nexus group via `ci/maven-settings.xml`. This
also solves parent bootstrap: Maven knows Nexus before it tries to resolve the shared parent.

## Pipeline behavior

1. `verify` runs `clean install` on the shared reactor, including starter unit tests.
2. It separately builds `consumer-template/pom.xml`, whose parent uses `<relativePath/>`. This checks
   that a consumer can resolve the parent and starter from Maven's local repository, outside the reactor.
3. Protected `vX.Y.Z` tag pipelines run `clean deploy`; the tag must match the POM release version.
4. Protected default-branch pipelines publish only when the POM ends in `-SNAPSHOT`. A release POM
   on that branch causes snapshot publishing to exit without publishing.

The consumer packaging check uses artifacts installed by the build, not an already-published Nexus
release. After the first release, a consumer build from a clean Maven cache verifies Nexus delivery.
`deployAtEnd` avoids uploading modules before reactor success but Nexus publication is not an atomic
multi-artifact transaction. Configure release repositories to reject redeployment; investigate partial
upload failures instead of overwriting a release. No application is deployed by these pipelines.

## Local build and IntelliJ

Use JDK 17 and Maven 3.9.x (IntelliJ's bundled Maven works). Configure the Nexus environment variables
for the Maven importer process, not just the application run configuration. Merge `ci/maven-settings.xml`
into your user Maven settings or select that file in IntelliJ's Maven settings. Preserve existing company
mirror policies when doing so. Then open the root `pom.xml`.

```bash
mvn -B -ntp -s ci/maven-settings.xml clean install
mvn -B -ntp -s ci/maven-settings.xml -f consumer-template/pom.xml clean verify
```

The root POM is both the published parent and the small shared reactor. Only the starter is its child.
The starter is an ordinary library JAR; only consumer applications apply Spring Boot repackaging.

## Start a new workflow repository

After platform release publication, run from a checkout of this repository:

```bash
python3 tools/new-workflow.py onboarding-workflow ../onboarding-workflow \
  --gitlab-project YOUR_GROUP/commons-workflow
```

The generator sets the artifact ID, application name, schema/DB role names, run module, and GitLab
include path. It refuses to overwrite an existing directory. The generic Java package is deliberately
left for the team to refactor in IntelliJ. Open the generated `pom.xml`, set up Git in that directory,
and push it to its own GitLab project. The generated project depends only on the parent and starter;
it does not require a checkout of this shared repo to build.

Its POM has the following relationship:

```xml
<parent>
  <groupId>com.yourcompany.workflow</groupId>
  <artifactId>commons-workflow-parent</artifactId>
  <version>1.0.0</version>
  <relativePath/>
</parent>
<!-- Application coordinates go here. -->
<dependencies>
  <dependency>
    <groupId>com.yourcompany.workflow</groupId>
    <artifactId>commons-workflow-spring-boot-starter</artifactId>
  </dependency>
</dependencies>
```

A consumer pins its Maven parent version and its GitLab include tag independently; update both when
adopting a platform release. An include imports YAML configuration, not files, so the consumer template
also contains its own `ci/maven-settings.xml`. The shared template uses that consumer-local file.

## Extension and ownership contract

| Concern | Platform default | Consumer responsibility/override |
| --- | --- | --- |
| Database | One schema setting drives technical defaults | Provision schema/role, supply URL and secrets |
| Migration | Stable changelog path; disabled startup migration | Add changesets; execute migrations before production startup |
| Flowable schema | Startup schema updates disabled | Apply vendor schema install/upgrade procedure |
| Identity | JWT resource server | Supply issuer; implement business authorization and audience requirements |
| Security policy | API authenticated, health public, other paths denied | Provide a complete `SecurityFilterChain` to replace policy |
| Business IDs | UUID | Provide `BusinessKeyGenerator` bean |
| Logging | Validated request correlation header and MDC | Propagate ID to outbound/async operations as needed |
| Search | Indexing disabled | Enable/configure Enterprise search if needed; isolate indices |

Do not use `spring.main.allow-bean-definition-overriding=true` as an extension mechanism.
Default-bean backoff and configuration properties are the supported approach. For the security
extension, the consumer owns the complete replacement policy; providing any chain causes the shared
chain to back off. Native Flowable REST/UI routes are deliberately not exposed by the default shared
policy. Integrations that need those routes require an explicit application security policy.

The core engine uses schema-local tables. Applications with different delegates must not share those
tables; identical replicas of the same application may share them. Namespacing database schemas does
not isolate search indices automatically. Database roles should restrict access to their owned schemas.

`commons.workflow.schema` is required and validated. Low-precedence defaults are installed through an
EnvironmentPostProcessor, rather than shipping a conflicting `application.yml` inside a library.
Consumer properties, environment variables, and command-line arguments override those defaults.

## Release changes

For a new version, update the root POM version, `commons-workflow.version`, the starter's parent
version, the template's parent version, and its pinned CI include ref. Update upgrade notes for any
behavior/configuration change. For snapshots, use a valid existing CI template tag until the new tag
exists. Keep template version and platform artifacts synchronized; `tools/check-layout.py` checks the
Maven version linkage. Teams upgrade explicitly, with workflow-instance and database compatibility
checks. A central library release cannot silently upgrade an already-built application.

If you have a mandatory corporate Maven parent, adapt this parent to inherit it and preserve the Boot
BOM and necessary build plugin management. There is intentionally no third BOM artifact yet. Add one
only when real consumers cannot share a common parent.

## Verification status

Static XML/YAML/Java syntax and generator checks were performed. Unit tests, Maven compilation,
GitLab CI execution, Nexus uploads, and Enterprise runtime behavior were not executed here because
Maven/Docker and organization access were unavailable. See `docs/verification.md` before first release.

## Reference documentation

- [Flowable Enterprise setup](https://documentation.flowable.com/latest/develop/be/setup-dev-environment)
- [Flowable Enterprise dependencies](https://documentation.flowable.com/latest/develop/be/java-extensions)
- [Flowable 3.17 release notes](https://documentation.flowable.com/latest/admin/release-notes/3.17.0-release)
- [Spring Boot auto-configuration](https://docs.spring.io/spring-boot/reference/features/developing-auto-configuration.html)
- [GitLab reusable configuration](https://docs.gitlab.com/ci/yaml/includes/)
